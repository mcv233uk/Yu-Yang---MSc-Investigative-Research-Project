// ==============================================================
// File generated on Mon Aug 11 03:12:11 +0800 2025
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xcnn_stream_top.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XCnn_stream_top_CfgInitialize(XCnn_stream_top *InstancePtr, XCnn_stream_top_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_bus_BaseAddress = ConfigPtr->Ctrl_bus_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XCnn_stream_top_Start(XCnn_stream_top *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL) & 0x80;
    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL, Data | 0x01);
}

u32 XCnn_stream_top_IsDone(XCnn_stream_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XCnn_stream_top_IsIdle(XCnn_stream_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XCnn_stream_top_IsReady(XCnn_stream_top *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XCnn_stream_top_EnableAutoRestart(XCnn_stream_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL, 0x80);
}

void XCnn_stream_top_DisableAutoRestart(XCnn_stream_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_AP_CTRL, 0);
}

void XCnn_stream_top_InterruptGlobalEnable(XCnn_stream_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_GIE, 1);
}

void XCnn_stream_top_InterruptGlobalDisable(XCnn_stream_top *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_GIE, 0);
}

void XCnn_stream_top_InterruptEnable(XCnn_stream_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_IER);
    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_IER, Register | Mask);
}

void XCnn_stream_top_InterruptDisable(XCnn_stream_top *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_IER);
    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_IER, Register & (~Mask));
}

void XCnn_stream_top_InterruptClear(XCnn_stream_top *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XCnn_stream_top_WriteReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_ISR, Mask);
}

u32 XCnn_stream_top_InterruptGetEnabled(XCnn_stream_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_IER);
}

u32 XCnn_stream_top_InterruptGetStatus(XCnn_stream_top *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XCnn_stream_top_ReadReg(InstancePtr->Ctrl_bus_BaseAddress, XCNN_STREAM_TOP_CTRL_BUS_ADDR_ISR);
}

