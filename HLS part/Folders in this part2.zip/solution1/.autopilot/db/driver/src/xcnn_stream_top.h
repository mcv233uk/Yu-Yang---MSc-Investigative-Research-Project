// ==============================================================
// File generated on Mon Aug 11 03:12:11 +0800 2025
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XCNN_STREAM_TOP_H
#define XCNN_STREAM_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcnn_stream_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Ctrl_bus_BaseAddress;
} XCnn_stream_top_Config;
#endif

typedef struct {
    u32 Ctrl_bus_BaseAddress;
    u32 IsReady;
} XCnn_stream_top;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCnn_stream_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCnn_stream_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCnn_stream_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCnn_stream_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XCnn_stream_top_Initialize(XCnn_stream_top *InstancePtr, u16 DeviceId);
XCnn_stream_top_Config* XCnn_stream_top_LookupConfig(u16 DeviceId);
int XCnn_stream_top_CfgInitialize(XCnn_stream_top *InstancePtr, XCnn_stream_top_Config *ConfigPtr);
#else
int XCnn_stream_top_Initialize(XCnn_stream_top *InstancePtr, const char* InstanceName);
int XCnn_stream_top_Release(XCnn_stream_top *InstancePtr);
#endif

void XCnn_stream_top_Start(XCnn_stream_top *InstancePtr);
u32 XCnn_stream_top_IsDone(XCnn_stream_top *InstancePtr);
u32 XCnn_stream_top_IsIdle(XCnn_stream_top *InstancePtr);
u32 XCnn_stream_top_IsReady(XCnn_stream_top *InstancePtr);
void XCnn_stream_top_EnableAutoRestart(XCnn_stream_top *InstancePtr);
void XCnn_stream_top_DisableAutoRestart(XCnn_stream_top *InstancePtr);


void XCnn_stream_top_InterruptGlobalEnable(XCnn_stream_top *InstancePtr);
void XCnn_stream_top_InterruptGlobalDisable(XCnn_stream_top *InstancePtr);
void XCnn_stream_top_InterruptEnable(XCnn_stream_top *InstancePtr, u32 Mask);
void XCnn_stream_top_InterruptDisable(XCnn_stream_top *InstancePtr, u32 Mask);
void XCnn_stream_top_InterruptClear(XCnn_stream_top *InstancePtr, u32 Mask);
u32 XCnn_stream_top_InterruptGetEnabled(XCnn_stream_top *InstancePtr);
u32 XCnn_stream_top_InterruptGetStatus(XCnn_stream_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
