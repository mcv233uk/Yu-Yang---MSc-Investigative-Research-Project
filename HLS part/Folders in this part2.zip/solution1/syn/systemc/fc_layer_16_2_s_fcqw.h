// ==============================================================
// File generated on Mon Aug 11 03:12:11 +0800 2025
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __fc_layer_16_2_s_fcqw_H__
#define __fc_layer_16_2_s_fcqw_H__


#include <systemc>
using namespace sc_core;
using namespace sc_dt;




#include <iostream>
#include <fstream>

struct fc_layer_16_2_s_fcqw_ram : public sc_core::sc_module {

  static const unsigned DataWidth = 22;
  static const unsigned AddressRange = 32;
  static const unsigned AddressWidth = 5;

//latency = 1
//input_reg = 1
//output_reg = 0
sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in <sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


sc_lv<DataWidth> ram[AddressRange];


   SC_CTOR(fc_layer_16_2_s_fcqw_ram) {
        ram[0] = "0b0010000010111010001001";
        ram[1] = "0b0010110100101100011001";
        ram[2] = "0b0000110010110111010000";
        ram[3] = "0b1100011111101001001100";
        ram[4] = "0b0101011010111101011000";
        ram[5] = "0b1011100110001001011001";
        ram[6] = "0b0001011101001001100101";
        ram[7] = "0b1110000010101101011010";
        ram[8] = "0b1000110100111110000111";
        ram[9] = "0b1001001010111010111110";
        ram[10] = "0b1101011010011010111010";
        ram[11] = "0b1010100110001110111000";
        ram[12] = "0b1100110001100001000111";
        ram[13] = "0b0010111000001111011101";
        ram[14] = "0b0000000001011101110101";
        ram[15] = "0b0101000111000111101111";
        ram[16] = "0b1101011111001000100110";
        ram[17] = "0b1101001010000000111001";
        ram[18] = "0b1101001001001110000110";
        ram[19] = "0b0011001111101110110001";
        ram[20] = "0b1011101010000000100101";
        ram[21] = "0b0011100110011001101000";
        ram[22] = "0b1100001110111010000100";
        ram[23] = "0b0110001011010000110001";
        ram[24] = "0b0010100101010110010001";
        ram[25] = "0b0011100101001101101011";
        ram[26] = "0b0101011010110110101011";
        ram[27] = "0b0011101111111000010011";
        ram[28] = "0b0110001011001000111001";
        ram[29] = "0b1101010000011011111001";
        ram[30] = "0b1100010011001100000000";
        ram[31] = "0b1101001100101100101001";


SC_METHOD(prc_write_0);
  sensitive<<clk.pos();
   }


void prc_write_0()
{
    if (ce0.read() == sc_dt::Log_1) 
    {
            if(address0.read().is_01() && address0.read().to_uint()<AddressRange)
              q0 = ram[address0.read().to_uint()];
            else
              q0 = sc_lv<DataWidth>();
    }
}


}; //endmodule


SC_MODULE(fc_layer_16_2_s_fcqw) {


static const unsigned DataWidth = 22;
static const unsigned AddressRange = 32;
static const unsigned AddressWidth = 5;

sc_core::sc_in <sc_lv<AddressWidth> > address0;
sc_core::sc_in<sc_logic> ce0;
sc_core::sc_out <sc_lv<DataWidth> > q0;
sc_core::sc_in<sc_logic> reset;
sc_core::sc_in<bool> clk;


fc_layer_16_2_s_fcqw_ram* meminst;


SC_CTOR(fc_layer_16_2_s_fcqw) {
meminst = new fc_layer_16_2_s_fcqw_ram("fc_layer_16_2_s_fcqw_ram");
meminst->address0(address0);
meminst->ce0(ce0);
meminst->q0(q0);

meminst->reset(reset);
meminst->clk(clk);
}
~fc_layer_16_2_s_fcqw() {
    delete meminst;
}


};//endmodule
#endif
